<?php
include "include/config.inc.php";

$lang = $_GET['id'];

// validar se o idioma é autorizado
// percorrer ou utilizar uma função de vetores que me diga que a $LANG existe lá
if(1) {
	$_SESSION['idioma_frontoffice'] = $lang;
}

header("Location: index.php");
?>