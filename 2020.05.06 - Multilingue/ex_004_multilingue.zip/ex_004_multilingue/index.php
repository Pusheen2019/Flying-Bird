<?php
include "include/config.inc.php"; // 1º é um caminho relativo
include $arrConfig['dir_site'] . "/include/functions.inc.php"; // todos os restantes caminhos absolutos
include $arrConfig['dir_site'] . "/include/db.inc.php";
?>
<!DOCTYPE html>
<html lang="en" <?php echo ( $_SESSION['idioma_frontoffice'] == 'sa' ? 'class="rtl"' : '' ); ?>>
<head>
	<meta charset="UTF-8">
	<title>Multilingue</title>
	<link rel="stylesheet" href="<?php echo $arrConfig['url_site']; ?>/css/main.css">
</head>
<body>
	

	<div class="idiomas_frontoffice">
	<?php
	$str = '';
	foreach ($arrConfig['idiomas_frontoffice'] as $key => $value) {
		$ativo = ( $key == $_SESSION['idioma_frontoffice'] ? 'class="ativo"' : '' );
		$str .= '<a '.$ativo.' href="'.$arrConfig['url_site'].'/lang.php?id='.$key.'">'.$value.'</a> | ';
	}
	echo substr($str, 0, strlen($str) - 3);
	?>
	</div>


	<div class="idiomas_frontoffice">
	<?php
	$str = '';
	foreach ($arrConfig['idiomas_frontoffice'] as $key => $value) {
		$ativo = ( $key == $_SESSION['idioma_frontoffice'] ? 'class="ativo"' : '' );
		$str .= '<a '.$ativo.' href="'.$arrConfig['url_site'].'/lang.php?id='.$key.'">'
		.'<img width="100" height="70" src="'.$arrConfig['url_site'].'/imgs/flags/'.$key.'.png" alt="'.$value.'" />'.
		'</a> ';
	}
	echo $str;
	?>
	</div>



	<?php
	echo '<h1>'.$lang['bom_dia'].'</h1>';
	echo $lang['bem_vindo'];
	?>




	<div class="produtos">
	<?php
	$query = "SELECT * FROM produtos P 
							INNER JOIN produtos_lang PL 
							ON P.id = PL.id 
							WHERE PL.lang = '".$_SESSION['idioma_frontoffice']."'";
	$res = my_query($query);

	foreach ($res as $key => $value) {
		echo '<div class="item">';
		echo '<img width="200" height="200" src="'.$arrConfig['url_site'].'/imgs/'.$value['foto'].'" alt="'.$value['nome'].'" />';
		echo '<span>'.$value['nome'].'</span>';
		echo '<em>'.number_format($value['preco'], 2, ',', '.').' € </em>';
		echo '</div>';
	}
	
	?>
	</div>


</body>
</html>