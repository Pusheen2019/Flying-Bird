<?php
$lang['bom_dia'] = 'Guten Morgen';
$lang['bem_vindo'] = 'Willkommen auf unserer mehrsprachigen Website!';
?>