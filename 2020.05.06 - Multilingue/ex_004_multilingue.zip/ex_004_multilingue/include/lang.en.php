<?php
$lang['bom_dia'] = 'Good morning';
$lang['bem_vindo'] = 'Welcome to our multilingual website!';
?>