<?php
@session_start();



$arrConfig['dir_site'] = 'D:/Hélder Couto/Desktop/COVID-19/12ITM/ex_004_multilingue';
$arrConfig['url_site'] = 'http://12itm.local/ex_004_multilingue';


// definição de idiomas
$arrConfig['idiomas_frontoffice'] = array (	'pt' => 'Português',
											'es' => 'Espanol',
											'fr' => 'Français',
											'de' => 'Deutsch',
											'en' => 'English',
											'ru' => 'Pусский',
											'sa' => 'عربي');
$arrConfig['default_idioma_frontoffice'] = 'en';



// carregar as traduções dos idiomas
if(!isset($_SESSION['idioma_frontoffice'])) {
	$_SESSION['idioma_frontoffice'] = $arrConfig['default_idioma_frontoffice'];
}
include $arrConfig['dir_site'] . '/include/lang.'.$_SESSION['idioma_frontoffice'].'.php';

?>