<?php
$lang['bom_dia'] = 'Bonjour';
$lang['bem_vindo'] = 'Bienvenue sur notre site multilingue!';
?>