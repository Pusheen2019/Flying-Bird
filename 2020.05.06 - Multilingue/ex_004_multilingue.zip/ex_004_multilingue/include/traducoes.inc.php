<?php




$lang['pt']['bemvindo'] = 'Bom dia, bem vindo ao nosso site multilingue!';
$lang['es']['bemvindo'] = '¡Buenos días, bienvenido a nuestro sitio web multilingüe!';
$lang['fr']['bemvindo'] = 'Bonjour, bienvenue sur notre site multilingue!';
$lang['de']['bemvindo'] = 'Guten Morgen, willkommen auf unserer mehrsprachigen Website!';
$lang['en']['bemvindo'] = 'Good morning, welcome to our multilingual website!';

?>