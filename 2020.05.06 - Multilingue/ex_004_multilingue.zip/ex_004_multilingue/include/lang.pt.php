<?php
$lang['bom_dia'] = 'Bom dia';
$lang['bem_vindo'] = 'Bem vindo ao nosso site multilingue!';
?>