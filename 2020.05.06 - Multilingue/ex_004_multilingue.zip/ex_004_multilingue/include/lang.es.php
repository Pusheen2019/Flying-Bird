<?php
$lang['bom_dia'] = '¡Buenos días';
$lang['bem_vindo'] = 'Bienvenido a nuestro sitio web multilingüe!';
?>